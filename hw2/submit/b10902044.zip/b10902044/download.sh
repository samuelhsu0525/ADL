#! /usr/bin/env bash
gdown https://drive.google.com/drive/u/1/folders/1PcxHQNN78IJQXVlP0kyejKM7PM_YGOe3 -O . --folder
gdown https://drive.google.com/drive/u/1/folders/193IsG-F8VWfRcIwT-WWv86y3aCk_VhkS -O model_1 --folder
