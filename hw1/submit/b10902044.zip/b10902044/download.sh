#! /usr/bin/env bash
gdown https://drive.google.com/drive/u/1/folders/1k6FwAEHZ6UQ5Tka59aa_oG1stkdJNLfu -O . --folder
gdown https://drive.google.com/drive/u/1/folders/1bWbUtI0ogiFFa46SuluASzRGW87ASr0n -O model_p1_shi_221 --folder
gdown https://drive.google.com/drive/u/1/folders/1VWRX1-U8ez9Y-RhmcnrehMANNqsjo5ns -O model_p1_shi_221_s64 --folder
gdown https://drive.google.com/drive/u/1/folders/1XCJRkyhRJyr0esY-7aarJQFaJ_82dtiN -O model_22 --folder
gdown https://drive.google.com/drive/u/1/folders/1OGcQQ4MPXaQnkAoX7RT5pGjv-6NqaK__ -O model_23 --folder
gdown https://drive.google.com/drive/u/1/folders/16poumXUYLZgL7naLnDLtnhNjGiia7Vr3 -O model_25 --folder
gdown https://drive.google.com/drive/u/1/folders/1NVHpIE-4rfWhokPTU7TtNfToEuCLWvQR -O model_27 --folder
gdown https://drive.google.com/drive/u/1/folders/1iMJ2rNdCkIpYLvfj0Ag1nAty_hNstgqN -O model_28 --folder
gdown https://drive.google.com/drive/u/1/folders/1PAnnsIxV0lO57bRfu35aQCQ3ZfTmARzX -O model_29 --folder