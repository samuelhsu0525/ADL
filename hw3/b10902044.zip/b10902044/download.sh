#! /usr/bin/env bash
gdown https://drive.google.com/drive/u/1/folders/1a3qhf9rkIT9wOwCepWCeOx-p8UCcXrW_ -O . --folder
gdown https://drive.google.com/drive/u/1/folders/1jkMVR_e-6Zrv863yyHHy8Kbj02pEwa3x -O adapter_checkpoint --folder